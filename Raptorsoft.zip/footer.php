<footer class="bg-dark">
<div class="row " style="margin: 0.1px;">
    <div class="col-12 my-3">
        <p class="text-secondary">Hola mundo</p>
    </div>
</div>
</footer>